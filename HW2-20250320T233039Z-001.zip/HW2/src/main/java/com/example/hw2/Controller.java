package com.example.hw2;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Controller {

    @FXML private TextField nameField;
    @FXML private TextField streetField;
    @FXML private TextField cityField;
    @FXML private TextField stateField;
    @FXML private TextField zipField;
    @FXML private CheckBox appCheckBox;
    @FXML private CheckBox musicCheckBox;
    @FXML private ComboBox<String> musicTypeComboBox;
    @FXML private RadioButton gameRadioButton;
    @FXML private RadioButton proRadioButton;
    @FXML private RadioButton eduRadioButton;
    @FXML private TextField titleField;
    @FXML private TextField dateField;
    @FXML private TextField accountField;
    @FXML private Button submitButton;
    @FXML private Button finishButton;
    @FXML private HBox appTypeBox;

    @FXML
    public void initialize() {
        // Add genres to the ComboBox
        musicTypeComboBox.getItems().addAll("CHOOSE ONE", "Pop", "Rock", "Jazz");
        musicTypeComboBox.setValue("CHOOSE ONE");

        // Set the visible row count for the ComboBox - use this instead of setMaxRowCount
        musicTypeComboBox.setVisibleRowCount(3);

        // Create ToggleGroup for radio buttons
        ToggleGroup appTypeGroup = new ToggleGroup();
        gameRadioButton.setToggleGroup(appTypeGroup);
        proRadioButton.setToggleGroup(appTypeGroup);
        eduRadioButton.setToggleGroup(appTypeGroup);

        // Add listeners to checkboxes
        appCheckBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal) {
                // If APP is selected, disable MUSIC and enable APP controls
                musicCheckBox.setSelected(false);
                toggleMusicControls(false);
                toggleAppControls(true);
            } else if (!musicCheckBox.isSelected()) {
                // If neither is selected, enable both
                toggleMusicControls(true);
                toggleAppControls(true);
            }
        });

        musicCheckBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal) {
                // If MUSIC is selected, disable APP and enable MUSIC controls
                appCheckBox.setSelected(false);
                toggleAppControls(false);
                toggleMusicControls(true);
            } else if (!appCheckBox.isSelected()) {
                // If neither is selected, enable both
                toggleAppControls(true);
                toggleMusicControls(true);
            }
        });

        // Set the focus to the name field
        nameField.requestFocus();
    }

    private void toggleMusicControls(boolean enabled) {
        musicTypeComboBox.setDisable(!enabled);
        if (enabled && appCheckBox.isSelected()) {
            enabled = false;
        }

        // Only change these controls if this product type is selected
        if (musicCheckBox.isSelected() || !appCheckBox.isSelected()) {
            titleField.setDisable(!enabled);
            dateField.setDisable(!enabled);
        }
    }

    private void toggleAppControls(boolean enabled) {
        gameRadioButton.setDisable(!enabled);
        proRadioButton.setDisable(!enabled);
        eduRadioButton.setDisable(!enabled);

        if (enabled && musicCheckBox.isSelected()) {
            enabled = false;
        }

        // Only change these controls if this product type is selected
        if (appCheckBox.isSelected() || !musicCheckBox.isSelected()) {
            accountField.setDisable(!enabled);
        }
    }

    @FXML
    private void handleSubmitButton() {
        // Validate all fields
        if (!validateInput()) {
            return;
        }

        // Create the customer data string
        String customerData = createCustomerDataString();

        // Add to the static array in Main class
        Main.customers.add(customerData);

        // Write to the appropriate file
        saveCustomerToFile(customerData);

        // Clear all fields and set focus to name field
        clearFields();
        nameField.requestFocus();
    }

    private boolean validateInput() {
        // Check common fields
        if (nameField.getText().trim().isEmpty()) {
            showAlert("Name is required");
            nameField.requestFocus();
            return false;
        }

        if (streetField.getText().trim().isEmpty()) {
            showAlert("Street is required");
            streetField.requestFocus();
            return false;
        }

        if (cityField.getText().trim().isEmpty()) {
            showAlert("City is required");
            cityField.requestFocus();
            return false;
        }

        if (stateField.getText().trim().isEmpty()) {
            showAlert("State is required");
            stateField.requestFocus();
            return false;
        }

        if (zipField.getText().trim().isEmpty()) {
            showAlert("Zip is required");
            zipField.requestFocus();
            return false;
        }

        // Check if either APP or MUSIC is selected
        if (!appCheckBox.isSelected() && !musicCheckBox.isSelected()) {
            showAlert("Please select either APP or MUSIC");
            return false;
        }

        // Validate APP-specific fields
        if (appCheckBox.isSelected()) {
            if (!gameRadioButton.isSelected() &&
                    !proRadioButton.isSelected() &&
                    !eduRadioButton.isSelected()) {
                showAlert("Please select an App type");
                return false;
            }

            if (accountField.getText().trim().isEmpty()) {
                showAlert("Account Number is required");
                accountField.requestFocus();
                return false;
            }
        }

        // Validate MUSIC-specific fields
        if (musicCheckBox.isSelected()) {
            if (musicTypeComboBox.getValue().equals("CHOOSE ONE")) {
                showAlert("Please select a Music type");
                musicTypeComboBox.requestFocus();
                return false;
            }

            if (titleField.getText().trim().isEmpty()) {
                showAlert("Title is required");
                titleField.requestFocus();
                return false;
            }

            if (dateField.getText().trim().isEmpty()) {
                showAlert("Date is required");
                dateField.requestFocus();
                return false;
            }
        }

        return true;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Input Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private String createCustomerDataString() {
        StringBuilder sb = new StringBuilder();

        // Common fields
        sb.append("Name: ").append(nameField.getText().trim()).append(", ");
        sb.append("Address: ").append(streetField.getText().trim()).append(", ");
        sb.append(cityField.getText().trim()).append(", ");
        sb.append(stateField.getText().trim()).append(" ");
        sb.append(zipField.getText().trim()).append(", ");

        String productType = appCheckBox.isSelected() ? "APP" : "MUSIC";
        sb.append("Product Type: ").append(productType);

        if (appCheckBox.isSelected()) {
            // App-specific fields
            String appType = gameRadioButton.isSelected() ? "GAME" :
                    (proRadioButton.isSelected() ? "PRODUCTIVITY" : "EDUCATION");
            sb.append(", App Type: ").append(appType);
            sb.append(", Account Number: ").append(accountField.getText().trim());
        } else {
            // Music-specific fields
            sb.append(", Music Type: ").append(musicTypeComboBox.getValue());
            sb.append(", Title: ").append(titleField.getText().trim());
            sb.append(", Date Purchased: ").append(dateField.getText().trim());
        }

        return sb.toString();
    }

    private void saveCustomerToFile(String customerData) {
        String fileName = appCheckBox.isSelected() ? "app.txt" : "music.txt";

        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            writer.println(customerData);
            System.out.println("Data saved to " + fileName + ": " + customerData);
        } catch (IOException e) {
            showAlert("Error saving to file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clearFields() {
        nameField.clear();
        streetField.clear();
        cityField.clear();
        stateField.clear();
        zipField.clear();
        appCheckBox.setSelected(false);
        musicCheckBox.setSelected(false);
        musicTypeComboBox.setValue("CHOOSE ONE");
        gameRadioButton.setSelected(false);
        proRadioButton.setSelected(false);
        eduRadioButton.setSelected(false);
        titleField.clear();
        dateField.clear();
        accountField.clear();

        // Reset enabled/disabled state
        toggleAppControls(true);
        toggleMusicControls(true);
    }

    @FXML
    private void handleFinishButton() {
        System.exit(0);
    }
}