package com.example.hw2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;

public class Main extends Application {
    // Array to store customer data
    public static ArrayList<String> customers = new ArrayList<>();

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("customer_form.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root, 800, 390);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Mav Tunes");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}